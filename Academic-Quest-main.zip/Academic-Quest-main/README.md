# Academic-Quest
A website to search better schools near you.

How to use ? 
1) Open the database.sql and copy the data and paste in the localhost myql server.
2) The database schoolsearch and table schools gets created.
3) Save all the files of the folder to the htdocs of xampp (for apache connection).
4) Open the localhost and open the folder link.
5) The website interface appears. 
6) Put in the city and class information to browse schools and the vacancies for the selected class.
7) If the selected class is 11th or 12th, the stream is also asked (arts,commerce,science).
8) About and Services page has also been added.
