<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">  
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About us</title>
    <link rel="stylesheet" href="css_home.css">
    <link rel="icon" href  = "img_logo.ico">
</head>
<body>
    <button class="btn1" ><a href="index.php">HOME</a></button>
    <center><h1>ABOUT</h1></center><br><br><br><br>
    <center><div>
    We are students second year students of IIT Mandi taking part in one of the intra college events.

We have found out the problem that generally parents do rush here and there to find schools for their childs and if they don;t have knowledge of seat availablity or last date for deadline, they becomes panic and it creates chaos.
        <br><br><br>
        <b>DETAILS OF MEMBERS:</b><br><br>
            <i>Shubham Shukla</i><br>
            EMAIL.ID:<i>b20168@students.iitmandi.ac.in</i><br><br>
            <i>Pallav Varshney</i><br>
            EMAIL.ID:<i>b20160@students.iitmandi.ac.in</i><br><br>
            <i>Alok Raj<br>
            EMAIL.ID:<i>b20274@students.iitmandi.ac.in</i><br>

    </div>
    </center>
    <br><br><br><br><br> 
    </body>

</html>