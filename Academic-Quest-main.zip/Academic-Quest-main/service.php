<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service</title>
    <link rel="stylesheet" href="css_home.css">
    <link rel="icon" href  = "img_logo.ico">
</head>
<body>
    <button class="btn1" ><a href="index.php">HOME</a></button>
    <center><h1>SERVICE</h1></center><br><br><br><br>
    <center><div><u>Hack36</u> organized by IIT Mandi.
        We have created a web interface which helps parents and guardians find schools in their cities. 
        The vacancies available in the school for a selected class is also shown along with the rating of the school 
        and their official website link.
        The registration deadline is also displayed, which helps the parents to choose the school in time for the admission interview process.
        This way,  the process of school searching becomes easy and less time-consuming.
    </div>
    </center>  
    </body>

</html>